from collections import defaultdict
import math
import sys

# Set of characters in training
TRAIN_LETTERS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789(),.-!?\"' ")
CHARACTER_WIDTH = 14
CHARACTER_HEIGHT = 25
MAX_VAL = 1e10
MIN_VAL = sys.float_info.epsilon

class OCRSolver:
    def __init__(self, train_letters, test_letters, train_txt_fname):
        self.train_letters = train_letters
        self.test_letters = test_letters
        self.init_prob = defaultdict(lambda: MIN_VAL)
        self.char_prob = defaultdict(lambda: MIN_VAL)
        self.trans_prob = defaultdict(lambda: defaultdict(lambda: MIN_VAL))
        self.emit_prob = defaultdict(dict)

        self.train(train_txt_fname)

    def train(self, train_txt_fname):
        """Train on a text corpus to calculate probabilities."""
        def clean_text(text):
            return ''.join([c if c in TRAIN_LETTERS else ' ' for c in text])

        with open(train_txt_fname, 'r') as file:
            data = clean_text(file.read())

        # Initialize probabilities
        for i in range(len(data) - 1):
            curr_char, next_char = data[i], data[i + 1]
            self.init_prob[curr_char] += 1 if i == 0 or data[i - 1] == ' ' else 0
            self.char_prob[curr_char] += 1
            self.trans_prob[curr_char][next_char] += 1

        # Normalize probabilities
        self.init_prob = self.normalize_dict(self.init_prob)
        self.char_prob = self.normalize_dict(self.char_prob)
        for char, next_chars in self.trans_prob.items():
            self.trans_prob[char] = self.normalize_dict(next_chars)

        self.compute_emission()

    @staticmethod
    def normalize_dict(dictionary):
        """Normalize a dictionary to represent log-probabilities."""
        total = sum(dictionary.values())
        for key in dictionary:
            dictionary[key] = -math.log(dictionary[key] / total) if dictionary[key] > 0 else MAX_VAL
        return dictionary

    def compute_emission(self):
        """Compute emission probabilities for all test letters."""
        def match_score(grid1, grid2):
            matches = sum(c1 == c2 for row1, row2 in zip(grid1, grid2) for c1, c2 in zip(row1, row2))
            total = CHARACTER_WIDTH * CHARACTER_HEIGHT
            return matches / total

        for idx, test_letter in enumerate(self.test_letters):
            for train_char, train_letter in self.train_letters.items():
                score = match_score(test_letter, train_letter)
                prob = -math.log(score) if score > 0 else MAX_VAL
                self.emit_prob[idx][train_char] = prob

    def simplified(self):
        """Simplified decoding using emission probabilities only."""
        result = []
        for idx in range(len(self.test_letters)):
            best_char = min(self.emit_prob[idx], key=self.emit_prob[idx].get, default=" ")
            result.append(best_char)
        return ''.join(result)

    def hmm_ve(self):
        """Decoding using Variable Elimination."""
        dp = defaultdict(lambda: defaultdict(lambda: MAX_VAL))
        dp[0] = {char: self.init_prob[char] + self.emit_prob[0].get(char, MAX_VAL) for char in self.train_letters}

        for t in range(1, len(self.test_letters)):
            for curr_char in self.train_letters:
                dp[t][curr_char] = min(
                    dp[t - 1][prev_char] + self.trans_prob[prev_char][curr_char] for prev_char in self.train_letters
                ) + self.emit_prob[t].get(curr_char, MAX_VAL)

        return ''.join(min(dp[t], key=dp[t].get) for t in range(len(self.test_letters)))

    def hmm_viterbi(self):
        """Decoding using Viterbi algorithm."""
        dp = defaultdict(lambda: defaultdict(lambda: MAX_VAL))
        backpointer = defaultdict(dict)

        dp[0] = {char: self.init_prob[char] + self.emit_prob[0].get(char, MAX_VAL) for char in self.train_letters}

        for t in range(1, len(self.test_letters)):
            for curr_char in self.train_letters:
                best_prev_char = min(
                    self.train_letters,
                    key=lambda prev_char: dp[t - 1][prev_char] + self.trans_prob[prev_char][curr_char]
                )
                dp[t][curr_char] = dp[t - 1][best_prev_char] + self.trans_prob[best_prev_char][curr_char] + \
                                   self.emit_prob[t].get(curr_char, MAX_VAL)
                backpointer[t][curr_char] = best_prev_char

        last_char = min(dp[len(self.test_letters) - 1], key=dp[len(self.test_letters) - 1].get)
        result = [last_char]
        for t in range(len(self.test_letters) - 1, 0, -1):
            last_char = backpointer[t][last_char]
            result.append(last_char)

        return ''.join(result[::-1])
