from PIL import Image
import sys
from ocr_solver import OCRSolver

CHARACTER_WIDTH = 14
CHARACTER_HEIGHT = 25

def load_letters(fname):
    """Load letter data from image."""
    im = Image.open(fname)
    px = im.load()
    (x_size, y_size) = im.size
    result = []
    for x_beg in range(0, int(x_size / CHARACTER_WIDTH) * CHARACTER_WIDTH, CHARACTER_WIDTH):
        result += [["".join(['*' if px[x, y] < 1 else ' ' for x in range(x_beg, x_beg + CHARACTER_WIDTH)]) for y in
                    range(0, CHARACTER_HEIGHT)], ]
    return result

def load_training_letters(fname):
    """Load training letters as a dictionary."""
    TRAIN_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789(),.-!?\"' "
    letter_images = load_letters(fname) 
    return {TRAIN_LETTERS[i]: letter_images[i] for i in range(len(TRAIN_LETTERS))}

def calculate_accuracy(predicted, ground_truth):
    """Calculate accuracy by comparing predictions with ground truth."""
    correct = sum(p == g for p, g in zip(predicted, ground_truth))
    return (correct / len(ground_truth)) * 100 if len(ground_truth) > 0 else 0

# Main execution
(train_img_fname, train_txt_fname, test_img_fname, ground_truth_fname) = sys.argv[1:]

train_letters = load_training_letters(train_img_fname)
test_letters = load_letters(test_img_fname)

# Load ground truth
with open(ground_truth_fname, 'r') as gt_file:
    ground_truth = gt_file.read().strip()

# Initialize the solver
solver = OCRSolver(train_letters, test_letters, train_txt_fname)

# Get predictions
simplified_result = solver.simplified()
hmm_ve_result = solver.hmm_ve()
hmm_viterbi_result = solver.hmm_viterbi()

# Calculate accuracies
simplified_accuracy = calculate_accuracy(simplified_result, ground_truth)
hmm_ve_accuracy = calculate_accuracy(hmm_ve_result, ground_truth)
hmm_viterbi_accuracy = calculate_accuracy(hmm_viterbi_result, ground_truth)

# Print results and accuracies
print(f"Simplified Result: {simplified_result}")
print(f"Simplified Accuracy: {simplified_accuracy:.2f}%")

print(f"HMM VE Result: {hmm_ve_result}")
print(f"HMM VE Accuracy: {hmm_ve_accuracy:.2f}%")

print(f"HMM Viterbi Result: {hmm_viterbi_result}")
print(f"HMM Viterbi Accuracy: {hmm_viterbi_accuracy:.2f}%")
