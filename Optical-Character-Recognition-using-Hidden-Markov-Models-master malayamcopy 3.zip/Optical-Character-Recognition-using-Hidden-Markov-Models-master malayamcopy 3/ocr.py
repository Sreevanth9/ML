from PIL import Image
import sys
from ocr_solver import OCRSolver

# Adjust based on actual character size in the images
CHARACTER_WIDTH = 16
CHARACTER_HEIGHT = 28

def load_letters(fname):
    im = Image.open(fname).convert('L')  # Convert image to grayscale
    px = im.load()
    (x_size, y_size) = im.size
    print(f"Image size: {im.size}")
    
    result = []
    threshold = 150  # Can be adjusted for better results

    for x_beg in range(0, int(x_size / CHARACTER_WIDTH) * CHARACTER_WIDTH, CHARACTER_WIDTH):
        if x_beg + CHARACTER_WIDTH > x_size:  # Ensure bounds are respected
            break
        letter_representation = []
        for y in range(0, min(CHARACTER_HEIGHT, y_size)):  # Ensure y is within bounds
            row_representation = "".join(['*' if px[x, y] < threshold else ' ' for x in range(x_beg, min(x_beg + CHARACTER_WIDTH, x_size))])
            letter_representation.append(row_representation)
        result.append(letter_representation)
    return result

def load_training_letters(fname):
    # Malayalam characters and digits included in TRAIN_LETTERS
    TRAIN_LETTERS = "അആഇഈഉഊഋഎഏഐഒഓഔകഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരലവശഷസഹളഴറ0123456789(),.-!?\"' "
    letter_images = load_letters(fname)
    return {TRAIN_LETTERS[i]: letter_images[i] for i in range(0, len(TRAIN_LETTERS))}

# Check for the correct number of arguments
if len(sys.argv) != 4:
    print("Usage: python ocr.py <train_img_fname> <train_txt_fname> <test_img_fname>")
    sys.exit(1)

# Extract command-line arguments
(train_img_fname, train_txt_fname, test_img_fname) = sys.argv[1:]

# Load training and test letters
train_letters = load_training_letters(train_img_fname)
test_letters = load_letters(test_img_fname)

# Initialize OCR solver and run methods
solver = OCRSolver(train_letters, test_letters, train_txt_fname)
solver.simplified()
solver.hmm_ve()
solver.hmm_viterbi()
