from collections import defaultdict
import math
import sys

TRAIN_LETTERS = set("അആഇഈഉഊഋഎഏഐഒഓഔകഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരലവശഷസഹളഴറ0123456789(),.-!?\"' ")
CHARACTER_WIDTH = 16
CHARACTER_HEIGHT = 28
max_val = 10000000.0
min_val = sys.float_info.epsilon

class OCRSolver:
    def __init__(self, train_letters, test_letters, train_txt_fname):
        self.train_letters = train_letters
        self.test_letters = test_letters

        self.init_prob = dict()
        self.char_prob = dict()
        for char in TRAIN_LETTERS:
            self.char_prob[char] = min_val

        self.trans_prob = defaultdict(dict)
        for row_char in TRAIN_LETTERS:
            for col_char in TRAIN_LETTERS:
                self.trans_prob[row_char][col_char] = min_val

        self.emit_prob = defaultdict(dict)
        self.train(train_txt_fname)

    def normalize_dict(self, dict_to_normalize):
        total_log = math.log(sum(dict_to_normalize.values()))
        for key, val in dict_to_normalize.items():
            dict_to_normalize[key] = max_val if val < 1 else total_log - math.log(val)

    def compute_emission(self):
        total_pixels = CHARACTER_WIDTH * CHARACTER_HEIGHT

        def match_grids(grid1, grid2):
            matches = 0
            for row1, row2 in zip(grid1, grid2):
                for ch1, ch2 in zip(row1, row2):
                    if ch1 == ch2:
                        matches += 1
            return matches

        for curr_index, test_letter in enumerate(self.test_letters):
            for train_letter, train_letter_grid in self.train_letters.items():
                matched = match_grids(test_letter, train_letter_grid)
                unmatched = total_pixels - matched
                match_prob = (matched + 0.0) / total_pixels
                prob = (match_prob ** matched) * ((1 - match_prob) ** unmatched)
                self.emit_prob[curr_index][train_letter] = max_val if prob == 0 else -math.log(prob)

    def train(self, train_txt_fname):
        def clean_string(str_to_clean):
            str_to_clean = list(str_to_clean)
            idx = 0
            while idx < len(str_to_clean) - 1:
                curr_ch = str_to_clean[idx]
                next_ch = str_to_clean[idx + 1]
                if curr_ch not in TRAIN_LETTERS:
                    str_to_clean[idx] = ' '
                if next_ch not in TRAIN_LETTERS:
                    str_to_clean[idx + 1] = ' '
                if next_ch == ' ' and (curr_ch == '.' or curr_ch == ' '):
                    del str_to_clean[idx + 1]
                else:
                    idx += 1
            return str_to_clean

        with open(train_txt_fname, 'r', encoding='utf-8') as train_txt_file:
            train_text = clean_string(train_txt_file.read())
            is_initial_letter = True
            for index in range(0, len(train_text) - 1):
                curr_char = train_text[index]
                next_char = train_text[index + 1]

                if is_initial_letter:
                    if curr_char not in self.init_prob:
                        self.init_prob[curr_char] = 0
                    self.init_prob[curr_char] += 1
                    is_initial_letter = False

                if curr_char == '.':
                    is_initial_letter = True

                self.trans_prob[curr_char][next_char] += 1
                self.char_prob[curr_char] += 1

        self.normalize_dict(self.init_prob)
        self.normalize_dict(self.char_prob)
        for row_dict in self.trans_prob.values():
            self.normalize_dict(row_dict)

        self.compute_emission()

    def simplified(self):
        output_chars = []
        for index, test_letter_grid in enumerate(self.test_letters):
            best_ch, best_prob = None, sys.float_info.max
            for ch, prob in self.emit_prob[index].items():
                curr_prob = prob + self.char_prob[ch]
                if curr_prob < best_prob:
                    best_ch, best_prob = ch, curr_prob
            output_chars.append(best_ch)
        print('Simple:', ''.join(output_chars))

    def hmm_ve(self):
        chars = {}
        char_dict = {char: self.char_prob[char] + self.emit_prob[0][char] for char in TRAIN_LETTERS}
        chars[0] = char_dict

        for w in range(1, len(self.test_letters)):
            prev_chars_dict = chars[w - 1]
            char_dict = {}
            for char in TRAIN_LETTERS:
                prob = 1 / sys.float_info.max
                for prev_char in prev_chars_dict:
                    current_prob = prev_chars_dict[prev_char] + self.trans_prob[prev_char][char]
                    prob += math.exp(-current_prob)
                char_dict[char] = -math.log(prob) + self.emit_prob[w][char]
            chars[w] = char_dict

        print('HMM VE:', ''.join([min(chars[w], key=chars[w].get) for w in range(len(self.test_letters))]))

    def hmm_viterbi(self):
        char_list = list(TRAIN_LETTERS)
        rows, cols = len(char_list), len(self.test_letters)
        vit_matrix = [[None] * cols for _ in range(rows)]

        for col_index in range(cols):
            curr_emission_probs = self.get_emission_probs(col_index)
            for row_index, curr_char in enumerate(char_list):
                if col_index == 0:
                    init_prob = self.init_prob.get(curr_char, max_val)
                    vit_matrix[row_index][col_index] = (-1, curr_emission_probs[curr_char] + init_prob)
                else:
                    best_prob_tuple = (-1, max_val)
                    for prev_row_index, prev_char in enumerate(char_list):
                        prev_prob = vit_matrix[prev_row_index][col_index - 1][1]
                        curr_prob = prev_prob + self.trans_prob[prev_char][curr_char] + curr_emission_probs[curr_char]
                        if curr_prob < best_prob_tuple[1]:
                            best_prob_tuple = (prev_row_index, curr_prob)
                    vit_matrix[row_index][col_index] = best_prob_tuple

        output_list = []
        max_index = min(range(rows), key=lambda i: vit_matrix[i][-1][1])
        for col in range(cols - 1, -1, -1):
            output_list.insert(0, char_list[max_index])
            max_index = vit_matrix[max_index][col][0]
        print('HMM Viterbi:', ''.join(output_list))

    def get_emission_probs(self, noisy_char):
        return {char: self.emit_prob[noisy_char].get(char, max_val) for char in TRAIN_LETTERS}
